
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

class Player {
  constructor(x, color, keys) {
    this.x = x;
    this.y = 300;
    this.vx = 0;
    this.vy = 0;
    this.color = color;
    this.keys = keys;
    this.width = 30;
    this.height = 30;
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.5; // gravity

    if (this.y + this.height > canvas.height) {
      this.y = canvas.height - this.height;
      this.vy = 0;
    }
  }

  draw() {
    ctx.fillStyle = this.color;
    ctx.fillRect(this.x, this.y, this.width, this.height);
  }
}

const p1 = new Player(200, "red", { left: "a", right: "d", up: "w" });
const p2 = new Player(550, "blue", { left: "ArrowLeft", right: "ArrowRight", up: "ArrowUp" });

let keysDown = {};

document.addEventListener("keydown", e => keysDown[e.key] = true);
document.addEventListener("keyup", e => delete keysDown[e.key]);

function handleInput(player) {
  if (keysDown[player.keys.left]) player.vx = -2;
  else if (keysDown[player.keys.right]) player.vx = 2;
  else player.vx = 0;

  if (keysDown[player.keys.up] && player.y + player.height >= canvas.height) {
    player.vy = -10;
  }
}

function checkCollision(p1, p2) {
  const dx = p1.x - p2.x;
  const dy = p1.y - p2.y;
  const distance = Math.sqrt(dx * dx + dy * dy);

  if (distance < 30) {
    if (p1.y < p2.y) alert("Kırmızı Kazandı!");
    else alert("Mavi Kazandı!");
    location.reload();
  }
}

function loop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  handleInput(p1);
  handleInput(p2);

  p1.update();
  p2.update();

  checkCollision(p1, p2);

  p1.draw();
  p2.draw();

  requestAnimationFrame(loop);
}

loop();
